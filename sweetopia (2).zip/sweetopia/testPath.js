// testPath.js (place in your project root)
const path = require('path');
const fs = require('fs');

const controllerPath = path.join(__dirname, 'controllers', 'userController.js');

console.log('Expected controller path:', controllerPath);
console.log('File exists:', fs.existsSync(controllerPath));