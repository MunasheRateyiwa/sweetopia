const API_URL = 'http://localhost:5000/api';
let token = localStorage.getItem('token') || '';

function output(msg) {
  const el = document.getElementById('output');
  if (el) el.textContent = JSON.stringify(msg, null, 2);
}

window.register = async function () {
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;

  const res = await fetch(`${API_URL}/users/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  });

  const data = await res.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    window.location.href = 'shop.html';
  } else {
    output(data);
  }
};

window.login = async function () {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  const res = await fetch(`${API_URL}/users/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  const data = await res.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    window.location.href = 'shop.html';
  } else {
    output(data);
  }
};

window.getCart = async function () {
  const res = await fetch(`${API_URL}/cart`, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
  });
  const data = await res.json();
  output(data);
};

window.onload = async function () {
  if (document.getElementById('product-list')) {
    const res = await fetch(`${API_URL}/products`);
    const products = await res.json();

    const container = document.getElementById('product-list');
    container.innerHTML = '';

    products.forEach(prod => {
      const div = document.createElement('div');
      div.className = 'product-card';
      div.innerHTML = `
        <img src="${prod.image}" alt="${prod.name}" />
        <h3>${prod.name}</h3>
        <p>${prod.description}</p>
        <p><strong>$${prod.price}</strong></p>
        <input type="number" min="1" value="1" id="qty-${prod._id}" />
        <button onclick="addToCart('${prod._id}', parseInt(document.getElementById('qty-${prod._id}').value))">
          Add to Cart
        </button>
      `;
      container.appendChild(div);
    });
  }
};

window.addToCart = async function (productId, quantity) {
  const res = await fetch(`${API_URL}/cart/add`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
    body: JSON.stringify({ productId, quantity }),
  });

  const data = await res.json();
  output(data);
};
<img src="/images/lollipop.png" alt="Lollipop" />
