const Cart = require('../models/Cart');

// GET /api/cart/
const getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user.id }).populate('items.productId');
    res.json(cart || { items: [] });
  } catch (err) {
    console.error('🔥 addToCart error:', err.message, err.stack);

    res.status(500).json({ message: 'Server error' });
  }
};

// POST /api/cart/add
const addToCart = async (req, res) => {
  const { productId, quantity } = req.body;

  console.log('👉 Add to cart request:', req.user, productId, quantity);

  if (!productId || quantity <= 0) {
    return res.status(400).json({ message: 'Invalid product or quantity' });
  }

  try {
    let cart = await Cart.findOne({ userId: req.user.id });
    if (!cart) {
      cart = new Cart({ userId: req.user.id, items: [] });
    }

    const index = cart.items.findIndex(item => item.productId.toString() === productId);
    if (index > -1) {
      cart.items[index].quantity += quantity;
    } else {
      cart.items.push({ productId, quantity });
    }

    await cart.save();
    res.json(cart);
  } catch (err) {
    console.error('🔥 addToCart error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// POST /api/cart/remove
const removeFromCart = async (req, res) => {
  const { productId } = req.body;

  try {
    const cart = await Cart.findOne({ userId: req.user.id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    cart.items = cart.items.filter(item => item.productId.toString() !== productId);
    await cart.save();
    res.json(cart);
  } catch (err) {
    console.error('🔥 removeFromCart error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// POST /api/cart/clear
const clearCart = async (req, res) => {
  try {
    await Cart.findOneAndDelete({ userId: req.user.id });
    res.json({ message: 'Cart cleared' });
  } catch (err) {
    console.error('🔥 clearCart error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  getCart,
  addToCart,
  removeFromCart,
  clearCart
};
