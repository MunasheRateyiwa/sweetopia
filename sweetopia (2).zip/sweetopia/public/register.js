const API_URL = 'http://localhost:5000/api'; // change this if deployed
let token = '';

document.getElementById('registerForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;

  const res = await fetch(`${API_URL}/users/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  });

  const data = await res.json();
  const output = document.getElementById('output');

  if (data.token) {
    token = data.token;
    localStorage.setItem('token', token);
    window.location.href = 'products.html'; // 👈 Redirect after successful registration
  } else {
    output.textContent = data.message || 'Registration failed.';
    output.style.color = 'red';
  }
});
