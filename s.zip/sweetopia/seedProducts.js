const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Product = require('./models/Product');

dotenv.config();

const sampleProducts = [
  {
    name: "Cotton Candy",
    description: "Fluffy sugar treat",
    price: 3.5,
    category: "Candy",
    imageUrl: "/images/cotton-candy.jpg"
  },
  {
    name: "Chocolate Fudge",
    description: "Rich, gooey chocolate squares",
    price: 4.99,
    category: "Chocolate",
    imageUrl: "/images/chocolate-fudge.jpg"
  },
  {
    name: "Rainbow Lollipop",
    description: "Swirly multicolor hard candy",
    price: 2.5,
    category: "Lollipops",
    imageUrl: "/images/rainbow-lollipop.jpg"
  },
  {
    name: "Sour Gummy Worms",
    description: "Tangy, chewy, rainbow-colored worms",
    price: 3.0,
    category: "Gummies",
    imageUrl: "/images/sour-gummy-worms.jpg"
  },
  {
    name: "Strawberry Jelly Beans",
    description: "Sweet and fruity bite-sized treats",
    price: 2.75,
    category: "Jelly Beans",
    imageUrl: "/images/strawberry-jelly-beans.jpg"
  }
];

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("Connected to MongoDB. Seeding products...");
    await Product.deleteMany();
    await Product.insertMany(sampleProducts);
    console.log("✅ Local-image products inserted!");
    process.exit();
  })
  .catch(err => {
    console.error("❌ MongoDB connection error:", err);
    process.exit(1);
  });
