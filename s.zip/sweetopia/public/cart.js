document.addEventListener("DOMContentLoaded", () => {
  renderCartItems();
});

function renderCartItems() {
  const cartContainer = document.getElementById("cartItems");
  cartContainer.innerHTML = ""; // Clear existing items

  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  
  if (cart.length === 0) {
    cartContainer.innerHTML = "<p>Your cart is empty 🧺</p>";
    return;
  }

  let total = 0;

  cart.forEach(item => {
    const itemDiv = document.createElement("div");
    itemDiv.classList.add("product-card");

    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    itemDiv.innerHTML = `
      <h3>${item.name}</h3>
      <p>Quantity: ${item.quantity}</p>
      <p>Price: $${item.price.toFixed(2)}</p>
      <p><strong>Subtotal: $${itemTotal.toFixed(2)}</strong></p>
    `;

    cartContainer.appendChild(itemDiv);
  });

  const totalDiv = document.createElement("div");
  totalDiv.innerHTML = `<h3>Total: $${total.toFixed(2)}</h3>`;
  totalDiv.classList.add("text-lg", "mt-4", "font-bold");
  cartContainer.appendChild(totalDiv);

  // Optional: Add a "Checkout" button
  const checkoutBtn = document.createElement("button");
  checkoutBtn.textContent = "Proceed to Checkout";
  checkoutBtn.classList.add("mt-4", "bg-green-500", "text-white", "px-4", "py-2", "rounded-md", "cursor-pointer");
  checkoutBtn.onclick = () => alert("Checkout not implemented yet 🛒");
  cartContainer.appendChild(checkoutBtn);
}

function clearCart() {
  localStorage.removeItem("cart");
  renderCartItems();
}
