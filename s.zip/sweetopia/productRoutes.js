const express = require('express');
const router = express.Router();

const products = [
  {
    id: 1,
    name: 'Chocolate Fudge',
    price: 3.99,
    image: 'chocolate-fudge.png'
  },
  {
    id: 2,
    name: 'Cotton Candy',
    price: 2.49,
    image: 'cotton-candy.png'
  },
  {
    id: 3,
    name: 'Rainbow Lollipop',
    price: 1.99,
    image: 'rainbow-lollipop.png'
  },
  {
    id: 4,
    name: 'Sour Gummy Worms',
    price: 2.99,
    image: 'sour-gummy-worms.png'
  },
  {
    id: 5,
    name: 'Strawberry Jelly Beans',
    price: 2.79,
    image: 'strawberry-jelly-beans.png'
  }
];

// ✅ This is the missing route!
router.get('/', (req, res) => {
  res.json(products);
});

module.exports = router;
